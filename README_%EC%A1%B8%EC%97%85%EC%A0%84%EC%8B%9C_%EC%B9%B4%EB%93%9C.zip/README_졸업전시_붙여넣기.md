## 🎓 졸업전시 제출 자료

> 프로젝트 결과물을 한 곳에서 확인할 수 있도록 정리했습니다. 아래 카드를 클릭하면 자료로 이동합니다.

| | | | |
|:---:|:---:|:---:|:---:|
| [![시연 영상](./readme_cards/demo.svg)](시연영상_URL) | [![ITPT 링크](./readme_cards/itpt.svg)](ITPT_URL) | [![Poster PDF](./readme_cards/poster.svg)](포스터_PDF_경로) | [![결과 보고서](./readme_cards/report.svg)](결과보고서_PDF_경로) |
